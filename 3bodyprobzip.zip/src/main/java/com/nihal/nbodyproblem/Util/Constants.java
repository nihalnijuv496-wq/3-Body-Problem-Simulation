package com.nihal.nbodyproblem.Util;


import javafx.scene.paint.Color;

public class Constants {
    public static final int N = 2;
    public static final int fps = 100;
    public static final double timeStep = 0.5;

    public static final int worldWidth = 1200;
    public static final int worldHeight = 700;

    public static final int buttonWidth = 100;
    public static final int buttonHeight = 50;

    public static final int cellWidth = 15;
    public static final int buttonSpacing = 50;

    public static final Color[] bodyColors =
            {Color.rgb(255, 0, 0),
            Color.rgb(0, 255, 0),
            Color.rgb(0,0, 255)};

    public static final double G = 100;
    public static final int epsilon = 0;

}
